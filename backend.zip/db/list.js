let mongoose=require('mongoose');
let schema=mongoose.Schema;
var listschema=new schema({
   task:{type:String},
  date:{type:Date}   
});
module.exports=mongoose.model('list',listschema);