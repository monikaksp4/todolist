let express=require('express');
let cors=require('cors');
let bodyParser=require('body-parser');
let mongoose=require('mongoose');
mongoose.connect("mongodb://localhost/MyToDoList1");
let listModel=require("./db/list");
let app=express();
app.use(cors());
app.use(bodyParser.json());
var distDir = __dirname + "/dist/";
app.use(express.static(distDir));
app.post('/addList',function(req,res)
{
    let task=req.body.task;
   let date=req.body.date;
  let ins=new listModel({task:task,date:date});
     ins.save(function(err)
      {
        if(err){
            res.json({'err':1,'msg':'data not insert'})
        }
         else
         {
             res.json({'err':0,'msg':'data insert'})
          }
         
     })
   
})
app.get('/fetchCat',function(req,res)
{
    listModel.find({},function(err,data)
{
    if(err){}
    else if(data.length==0)
    {
        res.json({err:1,msg:'No data found'})
    }
    else
    {
        res.json({err:0,msg:'Data fetched','data':data})
    }
})
})
app.get('/edit/:id',function (req, res) {
    let id = req.params.id;
    listModel.findById({'_id':id}, function (err, data){
        res.json(data);
    });
  });
  //update 

app.post('/update/:id',function (req, res) {
  let did=req.params.id;
   listModel.findById({'_id':did}, function(err,  list) {
  if(err){}
    else {
        list.task = req.body.task;
        list.date = req.body.date;
       console.log(list.date);
        list.save().then(list => {
          res.json('Update complete');
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });
    }
  });
});

app.get('/delCat/:id',function(req,res)
{
    let did=req.params.id;
    listModel.remove({'_id':did},function(err)
  {
      if(err)
      {}
      else
      {
          res.json({'err':0,'msg':'Category Deleted'})
      }
  })
})
app.listen(8899,function()
{
    console.log("Work on 8899");
})
