import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule}from '@angular/forms';
import { AppComponent } from './app.component';
import{HttpClientModule,HttpClient}from '@angular/common/http';

import{ReactiveFormsModule}from '@angular/forms';
import { EditComponent } from './edit/edit.component';
import { AddComponent } from './add/add.component';

import{RoutingModule}from './routing/routing.module';
import{SlimLoadingBarModule}from 'ng2-slim-loading-bar';
import{TodoserService}from './todoser.service';
import { DispComponent } from './disp/disp.component';
@NgModule({
  declarations: [
    AppComponent,
   EditComponent,
    AddComponent,
    DispComponent,

  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,
    ReactiveFormsModule,RoutingModule,SlimLoadingBarModule
  ],
  providers: [TodoserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
