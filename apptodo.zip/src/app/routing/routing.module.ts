import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{RouterModule,Routes}from '@angular/router';
import { EditComponent } from '../edit/edit.component';
import { AddComponent } from '../add/add.component';
import{DispComponent}from '../disp/disp.component';
const route:Routes=[
  { path: '',redirectTo: '/disp',pathMatch: 'full'},
  {path:'disp',component:DispComponent},
  {path:'add',component:AddComponent},
   {path:'edit/:id',component:EditComponent}
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,RouterModule.forRoot(route)
  ],
  exports:[RouterModule]
})
export class RoutingModule { }
