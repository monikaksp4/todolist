import { Component, OnInit ,OnDestroy} from '@angular/core';
import{FormBuilder,Validators,FormGroup}from '@angular/forms';
import{TodoserService}from '../todoser.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
myform:FormGroup;
  constructor(private fb:FormBuilder,private tser:TodoserService) { this.createForm();}

createForm()
{
  this.myform=this.fb.group(
    {'task':['',[Validators.required]]},
    {'date':['',[Validators.required]]}
  
  )
}
addTask(task,date) {
  this.tser.addTask(task,date);
}

  ngOnInit() {
  }

}
