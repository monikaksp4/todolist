import { Component, OnInit } from '@angular/core';
import{FormBuilder,Validators,FormGroup}from '@angular/forms';
import{ActivatedRoute,Router}from '@angular/router';

import{TodoserService}from '../todoser.service';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  list: any = {};
  angForm: FormGroup;

  constructor(private route: ActivatedRoute,
    private router: Router,
    private listser: TodoserService,
    private fb: FormBuilder) {
      this.createForm();
    }
    createForm() {
      this.angForm = this.fb.group({
             task: ['', Validators.required ],
              date: ['', Validators.required ]
         });
      }
     
      updateList(task,date) {
        this.route.params.subscribe(params => {
           this.listser.updateList(task, date,  params['id']);
           this.router.navigate(['disp']);
     });
    }
    ngOnInit() {
      this.route.params.subscribe(params => {
        this.listser.editList(params['id']).subscribe(res => {
          this.list = res;
      });
    });
  }

}
