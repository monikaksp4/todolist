import { Component, OnInit ,OnDestroy} from '@angular/core';
import{List} from './List';
import{TodoserService}from '../todoser.service';
@Component({
  selector: 'app-disp',
  templateUrl: './disp.component.html',
  styleUrls: ['./disp.component.css']
})
export class DispComponent implements OnInit ,OnDestroy{
lists:List[];
resData;
catData;
fetchtask;
sussMsg;
  constructor(private tser:TodoserService) { }
  fetchCat() {
    this.fetchtask = this.tser.fetchCat()
      .subscribe(res => {
        this.resData = res;
        if (this.resData.err == 0) {
          this.catData = this.resData.data;
          console.log(this.catData);
        }
      })
  }
  ngOnInit() {
   this.fetchCat();
  }
  delCat(id)
  {
    console.log(id)
    this.tser.delCat(id)
    .subscribe(res=>
    {
          this.resData=res;
          this.sussMsg=this.resData.msg;
          setTimeout(()=>{
            this.fetchCat();
          },2000)
    })
  }
  ngOnDestroy() {
  
    if (this.fetchtask) {
      this.fetchtask.unsubscribe();
    }
  }
}
