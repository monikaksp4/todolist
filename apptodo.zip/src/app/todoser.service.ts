import { Injectable } from '@angular/core';
import{HttpClient}from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TodoserService {

  url= 'http://localhost:8899/';

  constructor(private http: HttpClient) { }

  addTask(task, date) {
    const data = {
      task: task,
      date:date
    };
    console.log(data);
    this.http.post(this.url+'addList',data)
        .subscribe(res => console.log('Done'));
  }
  fetchCat()
  {
    return this.http.get(this.url+'fetchCat');
  }
  editList(id) {
    return this
              .http
              .get(this.url+'edit/'+id);
    }

    updateList(task,date ,id) {

      const obj = {
          task: task,
          date: date,
       
        };
      this
        .http
        .post(`${this.url}update/${id}`, obj)
        .subscribe(res => console.log('Done'));
    }
  delCat(id)
  {
    return this.http.get(this.url+'delCat/'+id)
  }

}
